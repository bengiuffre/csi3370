package com.example.test;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.FlowPane;
import javafx.stage.Stage;

public class HelloApplication extends Application {

    private ListView<String> itemList;  // listview to display available items
    private ListView<String> outputList; // listview to display items in the cart

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Blendify");

        // available lists
        itemList = new ListView<>();
        itemList.getItems().addAll("List 1", "List 2", "List 3", "List 4", "List 5", "List 6", "List 7", "List 8", "List 9", "List 10");

        // button stuff
        Button addButton = new Button("Add to Randomizer");
        addButton.setOnAction(e -> {
            String selectedItem = itemList.getSelectionModel().getSelectedItem();
            if (selectedItem != null) {
                outputList.getItems().add(selectedItem);
                itemList.getItems().remove(selectedItem);
            }
        });

        // remove button
        Button removeButton = new Button("Remove from Randomizer");
        removeButton.setOnAction(e -> {
            String selectedItem = outputList.getSelectionModel().getSelectedItem();
            if (selectedItem != null) {
                outputList.getItems().remove(selectedItem);
                itemList.getItems().add(selectedItem);
            }
        });

        // output area (cart)
        outputList = new ListView<>();

        // toggle button (like checkbox)
        ToggleButton toggleButton = new ToggleButton("Toggle Repeats");

        // dropdown button with a name
        ChoiceBox<String> choiceBox = new ChoiceBox<>();
        choiceBox.setId("choiceboxx"); // Set an ID as a name
        choiceBox.getItems().addAll("0", "1", "2", "3", "4");
        choiceBox.setValue("0"); // Set the default value

        // button layouts
        FlowPane topButtonLayout = new FlowPane();
        topButtonLayout.getChildren().addAll(addButton, removeButton);
        topButtonLayout.setAlignment(javafx.geometry.Pos.CENTER);
        topButtonLayout.setHgap(10); // Horizontal spacing between buttons
        topButtonLayout.setPadding(new Insets(0, 10, 0, 10)); // Padding on the sides

        // spacer for flowpane
        FlowPane spacer = new FlowPane();
        spacer.setPadding(new Insets(30, 0, 30, 0));

        // lower layout
        FlowPane bottomButtonLayout = new FlowPane();
        bottomButtonLayout.getChildren().addAll(toggleButton, new Label("Pair Amount:"), choiceBox);
        bottomButtonLayout.setAlignment(javafx.geometry.Pos.CENTER);
        bottomButtonLayout.setHgap(10); // Horizontal spacing between buttons
        bottomButtonLayout.setPadding(new Insets(15, 10, 15, 10)); // Padding on the sides

        // borderpane
        BorderPane topLayout = new BorderPane();
        topLayout.setTop(itemList);
        topLayout.setCenter(topButtonLayout);
        topLayout.setBottom(bottomButtonLayout);

        // layout
        BorderPane layout = new BorderPane();
        BorderPane.setMargin(addButton, new Insets(10));
        BorderPane.setMargin(removeButton, new Insets(10));

        layout.setTop(topLayout);

        // bottom layout
        layout.setBottom(outputList);

        Scene scene = new Scene(layout, 400, 625); // Set larger initial size
        primaryStage.setScene(scene);
        primaryStage.show();
    }
}
