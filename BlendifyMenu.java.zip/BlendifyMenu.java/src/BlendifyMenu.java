import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

public class BlendifyMenu extends Application {

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Blendify");
        primaryStage.setWidth(940);
        primaryStage.setHeight(940);

        // Create a BorderPane for the main content
        BorderPane mainPane = new BorderPane();

        // Create a GridPane for the main buttons
        GridPane buttonGrid = new GridPane();
        buttonGrid.setBackground(new Background(new BackgroundFill(Color.rgb(217, 217, 217), null, null)));

        Button randomizerButton = createButton("Randomizer");
        Button listEditorButton = createButton("List Editor");
        Button lightDarkModeButton = createButton("Light/Dark Mode");
        Button exitButton = createButton("Exit Application");

        setButtonSize(randomizerButton, 345, 100);
        setButtonSize(listEditorButton, 345, 100);
        setButtonSize(lightDarkModeButton, 345, 100);
        setButtonSize(exitButton, 345, 100);

        buttonGrid.add(randomizerButton, 0, 0);
        buttonGrid.add(listEditorButton, 1, 0);
        buttonGrid.add(lightDarkModeButton, 0, 1);
        buttonGrid.add(exitButton, 1, 1);

        // Create an HBox for the bottom buttons
        HBox bottomBox = new HBox();
        bottomBox.setAlignment(Pos.CENTER_LEFT);
        bottomBox.setBackground(new Background(new BackgroundFill(Color.rgb(217, 217, 217), null, null)));

        Button uninstallButton = createButton("Uninstall");
        Button resetButton = createButton("Reset");

        setButtonSize(uninstallButton, 170, 55);
        setButtonSize(resetButton, 170, 55);

        uninstallButton.setOnAction(e -> showAlert("Uninstall Button Clicked"));
        resetButton.setOnAction(e -> showAlert("Reset Button Clicked"));

        bottomBox.getChildren().addAll(uninstallButton, resetButton);

        // Add components to the main BorderPane
        mainPane.setCenter(buttonGrid);
        mainPane.setBottom(bottomBox);

        // Create a scene
        Scene scene = new Scene(mainPane);
        primaryStage.setScene(scene);

        // Show the stage
        primaryStage.show();
    }

    private Button createButton(String text) {
        Button button = new Button(text);
        button.setStyle("-fx-font-size: 18;");
        return button;
    }

    private void setButtonSize(Button button, double width, double height) {
        button.setMinSize(width, height);
        button.setMaxSize(width, height);
    }

    private void showAlert(String message) {
        Alert alert = new Alert(AlertType.INFORMATION);
        alert.setTitle("Information");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
